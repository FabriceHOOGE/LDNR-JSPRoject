<?php
header('Access-Control-Allow-Origin: *');
echo 'reçu : ', $_POST['message'];
?>
