<?php
header('Access-Control-Allow-Origin: *');
echo file_get_contents( "tchatContent.htm" ); // get the contents, and echo it out.
?>
